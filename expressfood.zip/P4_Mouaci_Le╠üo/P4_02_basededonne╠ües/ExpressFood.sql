-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: ExpressFood
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adresse` (
  `idAdresse` int(11) NOT NULL AUTO_INCREMENT,
  `destinataire` varchar(35) NOT NULL,
  `numeroVoie` varchar(5) NOT NULL,
  `rue` varchar(45) NOT NULL,
  `complementNumeroVoie` varchar(30) DEFAULT NULL,
  `codePostal` varchar(5) NOT NULL,
  `ville` varchar(15) NOT NULL,
  `client_users_idUsers` int(11) NOT NULL,
  PRIMARY KEY (`idAdresse`),
  UNIQUE KEY `idAdresse_UNIQUE` (`idAdresse`,`codePostal`,`ville`),
  KEY `fk_adresse_client1_idx` (`client_users_idUsers`),
  CONSTRAINT `fk_adresse_client1` FOREIGN KEY (`client_users_idUsers`) REFERENCES `client` (`users_idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (1,'M. Georges Thomas','7','Rue Sully',NULL,'24000','Périgueux',7),(2,'Mme Tomlon Marion','16','Rue de la république',NULL,'24000','Périgueux',8),(3,'M. Yung Chang','13','Rue de paris',NULL,'24000','Périgueux',9),(4,'Mme Faudal Barbara','20','Rue baudet',NULL,'24000','Périgueux',10);
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `numProduit` int(11) NOT NULL AUTO_INCREMENT,
  `quantiteTotale` int(11) NOT NULL,
  `nom` varchar(35) NOT NULL,
  `image` varchar(300) NOT NULL,
  `descriptif` varchar(60) DEFAULT NULL,
  `date` datetime NOT NULL,
  `prixUnitaireHT` decimal(8,2) NOT NULL,
  `tauxTVA100` decimal(8,2) NOT NULL,
  `chefCuisinier_users_idUsers` int(11) NOT NULL,
  PRIMARY KEY (`numProduit`),
  UNIQUE KEY `numProduit_UNIQUE` (`numProduit`),
  KEY `fk_article_chefCuisinier1_idx` (`chefCuisinier_users_idUsers`),
  CONSTRAINT `fk_article_chefCuisinier1` FOREIGN KEY (`chefCuisinier_users_idUsers`) REFERENCES `chefCuisinier` (`users_idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,7,'Salade printanière','https://img.cuisineaz.com/240x192/2013-12-20/i96628-salade-printaniere.jpg','à servir froid','2020-04-26 09:10:00',13.00,5.00,1),(2,13,'Pavé de saumon et asperges','https://larecette.net/wp-content/uploads/2020/04/iStock-174259528-728x409.jpg',NULL,'2020-04-26 09:15:00',23.00,5.00,2),(3,23,'Brownie aux pistaches grillées','https://cache.marieclaire.fr/data/photo/w600_c17/maison/brownies-aux-pistaches-grillees.webp',NULL,'2020-04-26 09:20:00',11.00,5.00,3),(4,9,'Moelleux aux pommes, frangipane','https://i.pinimg.com/564x/ae/6b/cf/ae6bcf29611e4a20e98673625302af56.jpg',NULL,'2020-04-26 09:25:00',9.00,5.00,3);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(60) NOT NULL,
  `descriptif` varchar(60) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorie`
--

LOCK TABLES `categorie` WRITE;
/*!40000 ALTER TABLE `categorie` DISABLE KEYS */;
INSERT INTO `categorie` VALUES (1,'plat',NULL,'2020-04-26 09:10:00'),(2,'dessert',NULL,'2020-04-26 09:15:00'),(3,'halal',NULL,'2020-04-26 09:20:00'),(4,'vegan',NULL,'2020-04-26 09:25:00');
/*!40000 ALTER TABLE `categorie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorie_has_article`
--

DROP TABLE IF EXISTS `categorie_has_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorie_has_article` (
  `categorie_id` int(11) NOT NULL,
  `article_numProduit` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`categorie_id`,`article_numProduit`),
  KEY `fk_categorie_has_article_article1_idx` (`article_numProduit`),
  KEY `fk_categorie_has_article_categorie1_idx` (`categorie_id`),
  CONSTRAINT `fk_categorie_has_article_article1` FOREIGN KEY (`article_numProduit`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_categorie_has_article_categorie1` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorie_has_article`
--

LOCK TABLES `categorie_has_article` WRITE;
/*!40000 ALTER TABLE `categorie_has_article` DISABLE KEYS */;
INSERT INTO `categorie_has_article` VALUES (1,1,7),(1,2,13),(2,3,23),(2,4,9),(3,2,13),(4,1,7);
/*!40000 ALTER TABLE `categorie_has_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chefCuisinier`
--

DROP TABLE IF EXISTS `chefCuisinier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chefCuisinier` (
  `users_idUsers` int(11) NOT NULL,
  PRIMARY KEY (`users_idUsers`),
  CONSTRAINT `fk_chefCuisinier_users1` FOREIGN KEY (`users_idUsers`) REFERENCES `users` (`idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chefCuisinier`
--

LOCK TABLES `chefCuisinier` WRITE;
/*!40000 ALTER TABLE `chefCuisinier` DISABLE KEYS */;
INSERT INTO `chefCuisinier` VALUES (1),(2),(3);
/*!40000 ALTER TABLE `chefCuisinier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `users_idUsers` int(11) NOT NULL,
  PRIMARY KEY (`users_idUsers`),
  KEY `fk_client_users1_idx` (`users_idUsers`),
  CONSTRAINT `fk_client_users1` FOREIGN KEY (`users_idUsers`) REFERENCES `users` (`idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (7),(8),(9),(10);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande` (
  `numeroCommande` int(11) NOT NULL AUTO_INCREMENT,
  `statut` varchar(15) NOT NULL,
  `delais` int(11) NOT NULL,
  `dateHeure` datetime NOT NULL,
  `prixUnitaireHT` decimal(8,2) NOT NULL,
  `tauxTVA100` decimal(8,2) NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `statutReglement` varchar(45) NOT NULL,
  `facture` varchar(300) NOT NULL,
  `adresse_idAdresse` int(11) NOT NULL,
  `client_users_idUsers` int(11) NOT NULL,
  `livreur_users_idUsers` int(11) NOT NULL,
  PRIMARY KEY (`numeroCommande`),
  UNIQUE KEY `numeroCommande_UNIQUE` (`numeroCommande`),
  KEY `fk_commande_adresse1_idx` (`adresse_idAdresse`),
  KEY `fk_commande_client1_idx` (`client_users_idUsers`),
  KEY `fk_commande_livreur1_idx` (`livreur_users_idUsers`),
  CONSTRAINT `fk_commande_adresse1` FOREIGN KEY (`adresse_idAdresse`) REFERENCES `adresse` (`idAdresse`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_client1` FOREIGN KEY (`client_users_idUsers`) REFERENCES `client` (`users_idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_livreur1` FOREIGN KEY (`livreur_users_idUsers`) REFERENCES `livreur` (`users_idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande`
--

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
INSERT INTO `commande` VALUES (1,'Livré',20,'2020-04-26 09:30:00',48.00,5.00,50.40,'Réglé','https://templates.invoicehome.com/modele-facture-fr-pur-750px.png',1,7,4),(2,'En cours',20,'2020-04-26 09:50:00',64.00,5.00,67.20,'Non Réglé','https://templates.invoicehome.com/modele-facture-fr-pur-750px.png',2,8,5),(3,'En cours',15,'2020-04-26 11:30:00',23.00,5.00,24.15,'Non Réglé','https://templates.invoicehome.com/modele-facture-fr-pur-750px.png',3,9,6);
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande_has_article`
--

DROP TABLE IF EXISTS `commande_has_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande_has_article` (
  `commande_numeroCommande` int(11) NOT NULL,
  `article_numProduit` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`commande_numeroCommande`,`article_numProduit`),
  KEY `fk_commande_has_article_article1_idx` (`article_numProduit`),
  KEY `fk_commande_has_article_commande1_idx` (`commande_numeroCommande`),
  CONSTRAINT `fk_commande_has_article_article1` FOREIGN KEY (`article_numProduit`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_commande_has_article_commande1` FOREIGN KEY (`commande_numeroCommande`) REFERENCES `commande` (`numeroCommande`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande_has_article`
--

LOCK TABLES `commande_has_article` WRITE;
/*!40000 ALTER TABLE `commande_has_article` DISABLE KEYS */;
INSERT INTO `commande_has_article` VALUES (1,1,2),(1,3,2),(2,2,2),(2,4,2),(3,2,1);
/*!40000 ALTER TABLE `commande_has_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livreur`
--

DROP TABLE IF EXISTS `livreur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livreur` (
  `users_idUsers` int(11) NOT NULL,
  `longitude` varchar(45) NOT NULL,
  `latitude` varchar(45) NOT NULL,
  `statut_livreur_id` int(11) NOT NULL,
  PRIMARY KEY (`users_idUsers`),
  KEY `fk_livreur_statut_livreur1_idx` (`statut_livreur_id`),
  CONSTRAINT `fk_livreur_statut_livreur1` FOREIGN KEY (`statut_livreur_id`) REFERENCES `statut_livreur` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_livreur_users1` FOREIGN KEY (`users_idUsers`) REFERENCES `users` (`idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livreur`
--

LOCK TABLES `livreur` WRITE;
/*!40000 ALTER TABLE `livreur` DISABLE KEYS */;
INSERT INTO `livreur` VALUES (4,'0.722452','45.182663',1),(5,'0.722452','45.182663',2),(6,'0.722452','45.182663',3);
/*!40000 ALTER TABLE `livreur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livreur_has_article`
--

DROP TABLE IF EXISTS `livreur_has_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livreur_has_article` (
  `livreur_users_idUsers` int(11) NOT NULL,
  `article_numProduit` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`livreur_users_idUsers`,`article_numProduit`),
  KEY `fk_livreur_has_article_article1_idx` (`article_numProduit`),
  KEY `fk_livreur_has_article_livreur1_idx` (`livreur_users_idUsers`),
  CONSTRAINT `fk_livreur_has_article_article1` FOREIGN KEY (`article_numProduit`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_livreur_has_article_livreur1` FOREIGN KEY (`livreur_users_idUsers`) REFERENCES `livreur` (`users_idUsers`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livreur_has_article`
--

LOCK TABLES `livreur_has_article` WRITE;
/*!40000 ALTER TABLE `livreur_has_article` DISABLE KEYS */;
INSERT INTO `livreur_has_article` VALUES (4,1,4),(4,2,4),(5,1,2),(5,2,2),(5,3,2),(5,4,2),(6,3,3),(6,4,3);
/*!40000 ALTER TABLE `livreur_has_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `date` datetime NOT NULL,
  `article_numProduit1` int(11) NOT NULL,
  `article_numProduit2` int(11) NOT NULL,
  `article_numProduit3` int(11) NOT NULL,
  `article_numProduit4` int(11) NOT NULL,
  PRIMARY KEY (`date`),
  UNIQUE KEY `date_UNIQUE` (`date`),
  KEY `fk_menu_article1_idx` (`article_numProduit1`),
  KEY `fk_menu_article2_idx` (`article_numProduit2`),
  KEY `fk_menu_article3_idx` (`article_numProduit3`),
  KEY `fk_menu_article4_idx` (`article_numProduit4`),
  CONSTRAINT `fk_menu_article1` FOREIGN KEY (`article_numProduit1`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_menu_article2` FOREIGN KEY (`article_numProduit2`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_menu_article3` FOREIGN KEY (`article_numProduit3`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_menu_article4` FOREIGN KEY (`article_numProduit4`) REFERENCES `article` (`numProduit`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES ('2020-04-26 09:25:00',1,2,3,4);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statut_livreur`
--

DROP TABLE IF EXISTS `statut_livreur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statut_livreur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statut` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `statut_UNIQUE` (`statut`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statut_livreur`
--

LOCK TABLES `statut_livreur` WRITE;
/*!40000 ALTER TABLE `statut_livreur` DISABLE KEYS */;
INSERT INTO `statut_livreur` VALUES (3,'En cours de livraison'),(4,'En réassort'),(1,'Indisponible'),(2,'Libre');
/*!40000 ALTER TABLE `statut_livreur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL AUTO_INCREMENT,
  `raisonSociale` varchar(45) DEFAULT NULL,
  `civilite` varchar(5) NOT NULL,
  `nom` varchar(15) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` varchar(45) NOT NULL,
  `motDePasse` varchar(25) NOT NULL,
  PRIMARY KEY (`idUsers`),
  UNIQUE KEY `idUsers_UNIQUE` (`idUsers`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Particulier','M.','Mouaci','Léo','LeoDavinciFr@gmail.com','zeuchezukch'),(2,NULL,'Mme','Richaud','Sara','Richaud.Sara@gmail.com','dfvefvelr'),(3,NULL,'Mme','Consa','Margarette','Consa.Margarette@gmail.com','sdfdszvrv'),(4,NULL,'M.','Roland','Greg','Roland.Greg@gmail.com','sdvvlkms'),(5,NULL,'M.','Bouchet','Marc','Bouchet.Marc@gmail.com','dsfjknzeszez'),(6,NULL,'Mme','Louisan','Rachel','Louisan.Rachel@gmail.com','lkezjfliejzfz'),(7,NULL,'M.','Georges','Thomas','Georges.Thomas@gmail.com','zehfezuehzu'),(8,NULL,'Mme','Tomlon','Marion','Tomlon.Marion@gmail.com','jkncejkzcnezkj'),(9,NULL,'M.','Yung','Chang','Yung.Chang@gmail.com','kjchezkjcheu'),(10,NULL,'Mme','Faudal','Barbara','Faudal.Barbara@gmail.com','kzjdhezkcjhez');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-28 11:41:11
